make main;
time ./main data.txt >> /dev/null
time ./main -t 2 data.txt >> /dev/null